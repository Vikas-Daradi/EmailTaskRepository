package com.example.taskapproval.service;

import com.example.taskapproval.model.Task;
import com.example.taskapproval.repository.TaskRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TaskService {
    @Autowired
    private TaskRepository taskRepository;

    @Autowired
    private EmailService emailService;

    public Task createTask(Task task) {
        Task savedTask = taskRepository.save(task);
        emailService.sendEmail("approver@example.com", "New Task Created", 
                "A new task '" + task.getName() + "' has been created. Please review it.");
        return savedTask;
    }

    public List<Task> getAllTasks() {
        return taskRepository.findAll();
    }
}
